import { integer, pgEnum, pgTable, serial, text, timestamp, varchar, numeric } from "drizzle-orm/pg-core";

const roleEnum = pgEnum("user_role", ["user", "admin"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: text("passwordHash"),
  cpf: varchar("cpf", { length: 11 }).unique(),
  birthDate: varchar("birthDate", { length: 10 }),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }).default("local"),
  role: roleEnum("role").default("user").notNull(),
  createdAt: timestamp("createdAt", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { withTimezone: true }).defaultNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn", { withTimezone: true }).defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  externalId: varchar("externalId", { length: 128 }).notNull().unique(),
  cashinId: varchar("cashinId", { length: 128 }),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  status: varchar("status", { length: 32 }).default("pending").notNull(),
  qrCode: text("qrCode"),
  copyPaste: text("copyPaste"),
  description: text("description"),
  createdAt: timestamp("createdAt", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { withTimezone: true }).defaultNow().notNull(),
});

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("userId").notNull(),
  cashinId: varchar("cashinId", { length: 128 }),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  pixKey: varchar("pixKey", { length: 320 }).notNull(),
  pixKeyType: varchar("pixKeyType", { length: 16 }).notNull(),
  status: varchar("status", { length: 32 }).default("processing").notNull(),
  createdAt: timestamp("createdAt", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updatedAt", { withTimezone: true }).defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Payment = typeof payments.$inferSelect;
export type Withdrawal = typeof withdrawals.$inferSelect;
