import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "./localAuth";

describe("local authentication", () => {
  it("hashes and verifies passwords without storing plaintext", async () => {
    const password = "SenhaSegura123!";
    const hash = await hashPassword(password);
    expect(hash).not.toContain(password);
    await expect(verifyPassword(password, hash)).resolves.toBe(true);
    await expect(verifyPassword("outra-senha", hash)).resolves.toBe(false);
  });
});
