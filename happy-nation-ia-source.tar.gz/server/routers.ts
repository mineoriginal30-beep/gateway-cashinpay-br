import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import axios from "axios";
import { TRPCError } from "@trpc/server";
import { createLocalSession, hashPassword, verifyPassword, newLocalOpenId, LOCAL_SESSION_COOKIE } from "./localAuth";
import { createLocalUser, getUserByEmail, getPaymentsByUser, getWithdrawalsByUser, insertPayment, insertWithdrawal } from "./db";

function makeCookie(name: string, value: string, options: Record<string, unknown>) {
  const parts = [`${name}=${encodeURIComponent(value)}`, "Path=/", "HttpOnly", "SameSite=Lax"];
  if (options.secure) parts.push("Secure");
  if (typeof options.maxAge === "number") parts.push(`Max-Age=${options.maxAge}`);
  return parts.join("; ");
}
const cashin = axios.create({ baseURL: "https://api.cashinpaybr.com/api/v1", timeout: 20000, validateStatus: () => true });
const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
const normalizeMoney = (value: number) => Math.round(value * 100) / 100;

async function cashinRequest(method: "get" | "post", path: string, data?: unknown) {
  const key = process.env.CASHINPAY_API_KEY;
  if (!key) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "CashinPay ainda não está configurada no servidor." });
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const response = await cashin.request({ method, url: path, data, headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" } });
      if (response.status >= 200 && response.status < 300) return response.data;
      const apiError = response.data?.error;
      const message = apiError?.message || response.data?.message || `A CashinPay recusou a operação (HTTP ${response.status}).`;
      if ([429, 502, 503, 504].includes(response.status) && attempt < 2) {
        await wait(400 * (attempt + 1));
        continue;
      }
      throw new TRPCError({ code: response.status === 401 ? "UNAUTHORIZED" : "BAD_REQUEST", message });
    } catch (error: any) {
      if (error instanceof TRPCError) throw error;
      if (attempt < 2 && (!error.response || [429, 502, 503, 504].includes(error.response.status))) {
        await wait(400 * (attempt + 1));
        continue;
      }
      throw new TRPCError({ code: "TIMEOUT", message: "A CashinPay não respondeu. Aguarde alguns segundos e tente novamente." });
    }
  }
  throw new TRPCError({ code: "TIMEOUT", message: "Não foi possível concluir a comunicação com a CashinPay." });
}
const cpf = z.string().regex(/^\d{11}$/, "CPF deve conter 11 números");
const pixType = z.enum(["cpf", "cnpj", "email", "phone", "random"]);

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    register: publicProcedure.input(z.object({ name: z.string().min(3), email: z.string().email(), password: z.string().min(8), cpf, birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), phone: z.string().min(10).optional() })).mutation(async ({ input, ctx }) => {
      if (await getUserByEmail(input.email)) throw new TRPCError({ code: "CONFLICT", message: "Este e-mail já está cadastrado." });
      const user = await createLocalUser({ ...input, passwordHash: await hashPassword(input.password), openId: newLocalOpenId() });
      if (!user) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível criar a conta." });
      ctx.res.setHeader("Set-Cookie", makeCookie(LOCAL_SESSION_COOKIE, await createLocalSession(user), { secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 7 }));
      return user;
    }),
    login: publicProcedure.input(z.object({ email: z.string().email(), password: z.string().min(1) })).mutation(async ({ input, ctx }) => {
      const user = await getUserByEmail(input.email);
      if (!user?.passwordHash || !(await verifyPassword(input.password, user.passwordHash))) throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos." });
      ctx.res.setHeader("Set-Cookie", makeCookie(LOCAL_SESSION_COOKIE, await createLocalSession(user), { secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 7 }));
      return user;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const options = getSessionCookieOptions(ctx.req);
      const response = ctx.res as any;
      if (typeof response.setHeader === "function") {
        response.setHeader("Set-Cookie", [makeCookie(LOCAL_SESSION_COOKIE, "", { ...options, maxAge: 0 }), makeCookie(COOKIE_NAME, "", { ...options, maxAge: 0 })]);
      } else if (typeof response.clearCookie === "function") {
        response.clearCookie(COOKIE_NAME, { ...options, maxAge: -1 });
      }
      return { success: true } as const;
    }),
  }),
  payments: router({
    list: protectedProcedure.query(({ ctx }) => getPaymentsByUser(ctx.user.id)),
    create: protectedProcedure.input(z.object({ amount: z.number().finite().min(5, "O valor mínimo é R$ 5,00.").max(10000, "O valor máximo é R$ 10.000,00."), description: z.string().max(200).optional(), phone: z.string().min(10) })).mutation(async ({ ctx, input }) => {
      const amount = normalizeMoney(input.amount);
      const phone = input.phone.replace(/\D/g, "");
      if (![10, 11].includes(phone.length)) throw new TRPCError({ code: "BAD_REQUEST", message: "Informe um telefone válido com DDD (10 ou 11 números)." });
      if (!ctx.user.email || !ctx.user.name) throw new TRPCError({ code: "BAD_REQUEST", message: "Complete nome e e-mail do cadastro antes de gerar o PIX." });
      const externalId = `gw_${ctx.user.id}_${Date.now()}`;
      const result = await cashinRequest("post", "/transactions", { amount, transaction_id: externalId, description: input.description || "Cobrança PIX", customer: { name: ctx.user.name, email: ctx.user.email, phone, document: ctx.user.cpf?.replace(/\D/g, "") } });
      const data = result?.data ?? result;
      const pix = data?.pix ?? result?.pix;
      if (!data?.id || !pix?.copy_paste) throw new TRPCError({ code: "BAD_GATEWAY", message: "A CashinPay respondeu sem o código PIX. Nenhuma cobrança foi registrada." });
      await insertPayment({ userId: ctx.user.id, externalId, cashinId: String(data.id), amount: amount.toFixed(2), status: data.status || "pending", qrCode: pix.qrcode, copyPaste: pix.copy_paste, description: input.description || "Cobrança PIX" });
      return { ...data, pix };
    }),
  }),
  withdrawals: router({
    list: protectedProcedure.query(({ ctx }) => getWithdrawalsByUser(ctx.user.id)),
    create: protectedProcedure.input(z.object({ amount: z.number().positive(), pixKey: z.string().min(3), pixKeyType: pixType })).mutation(async ({ ctx, input }) => {
      const result = await cashinRequest("post", "/withdrawals", { amount: input.amount, pix_key: input.pixKey, pix_key_type: input.pixKeyType });
      await insertWithdrawal({ userId: ctx.user.id, cashinId: String(result.data.id), amount: String(input.amount), pixKey: input.pixKey, pixKeyType: input.pixKeyType, status: result.data.status });
      return result.data;
    }),
  }),
  admin: router({ overview: protectedProcedure.query(async ({ ctx }) => { if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Acesso restrito à administração." }); return cashinRequest("get", "/balance"); }) }),
});
export type AppRouter = typeof appRouter;
